package br.com.fiap.bean;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class indexBean {
	
	public void executar() {
		System.out.println("Executando o Comando...");
	}
		
}
